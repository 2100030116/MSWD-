# Unicafe Redux

In this exercise, we made a simplified version of the unicafe-exercise from part 1 with handling of the state management with `Redux`. As a reminder, the unicafe app collects customer feedback with three options: good, neutral, and bad.

## Start the application

To start an application, do the following :

```bash
# Install dependancies
$ npm install
# Start the application
$ npm start
```

You can then access the app on : [http://localhost:3000/](http://localhost:3000/)